# ============================================================
#   🌿 Daily Wellness Dashboard — Streamlit Web App
#   Code Your Wellness | CS Girlies Workshop
#   By Rachel Ingabire — INGRA DIGITAL HUB
# ============================================================

import streamlit as st

# ── PAGE CONFIG ─────────────────────────────────────────────
st.set_page_config(
    page_title="Daily Wellness Tracker 🌸",
    page_icon="🌿",
    layout="centered"
)

# ── CUSTOM CSS ───────────────────────────────────────────────
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');

    html, body, [class*="css"] {
        font-family: 'Poppins', sans-serif;
    }

    .main { background-color: #F4FAF7; }

    .header-box {
        background: linear-gradient(135deg, #0D2818, #1A4731);
        padding: 2rem;
        border-radius: 16px;
        text-align: center;
        margin-bottom: 1.5rem;
    }
    .header-box h1 {
        color: #F4C0D1;
        font-size: 2rem;
        font-weight: 700;
        margin: 0;
    }
    .header-box p {
        color: #5EC99A;
        font-size: 1rem;
        margin-top: 0.5rem;
    }

    .score-card {
        background: white;
        border-radius: 16px;
        padding: 1.5rem;
        text-align: center;
        box-shadow: 0 2px 12px rgba(0,0,0,0.08);
        margin-bottom: 1rem;
    }
    .score-label {
        color: #4A7B60;
        font-size: 0.9rem;
        margin-bottom: 0.25rem;
    }
    .score-number {
        font-size: 3.5rem;
        font-weight: 700;
        margin: 0;
    }
    .score-msg {
        color: #4A7B60;
        font-style: italic;
        font-size: 0.95rem;
        margin-top: 0.25rem;
    }

    .tip-card {
        background: white;
        border-radius: 12px;
        padding: 1rem 1.25rem;
        margin-bottom: 0.75rem;
        box-shadow: 0 1px 6px rgba(0,0,0,0.06);
        border-left: 4px solid #D4537E;
    }
    .tip-title {
        font-weight: 600;
        color: #1A4731;
        font-size: 1rem;
        margin-bottom: 0.2rem;
    }
    .tip-body {
        color: #555555;
        font-size: 0.9rem;
    }

    .metric-card {
        background: white;
        border-radius: 12px;
        padding: 1rem;
        text-align: center;
        box-shadow: 0 1px 6px rgba(0,0,0,0.06);
    }
    .metric-label {
        font-size: 0.8rem;
        color: #888;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }
    .metric-val {
        font-size: 1.2rem;
        font-weight: 600;
        color: #1A4731;
    }

    div[data-testid="stNumberInput"] label {
        font-weight: 600;
        color: #1A4731;
        font-size: 1rem;
    }

    div[data-testid="stButton"] > button {
        background: linear-gradient(135deg, #D4537E, #B03D68);
        color: white;
        border: none;
        border-radius: 12px;
        padding: 0.75rem 2rem;
        font-size: 1.1rem;
        font-weight: 600;
        width: 100%;
        font-family: 'Poppins', sans-serif;
        transition: opacity 0.2s;
    }
    div[data-testid="stButton"] > button:hover {
        opacity: 0.88;
        color: white;
    }

    .section-title {
        color: #D4537E;
        font-size: 1.1rem;
        font-weight: 600;
        margin: 1.2rem 0 0.75rem 0;
    }

    .stProgress > div > div {
        border-radius: 99px;
    }

    hr { border-color: #E8F5EE; }
</style>
""", unsafe_allow_html=True)


# ── HEALTH LOGIC ─────────────────────────────────────────────
def analyse(water, sleep, steps, mood):
    score = 0
    tips  = []

    # Water
    if water >= 8:
        score += 25
        tips.append(("💧", "Hydration queen!", "You crushed your water goal today. Your skin is glowing!"))
    else:
        need = 8 - water
        score += int((water / 8) * 25)
        tips.append(("💧", "Drink more water!", f"You need {need:.0f} more glass{'es' if need != 1 else ''} to hit 8 today. Keep a bottle on your desk!"))

    # Sleep
    if sleep >= 7:
        score += 25
        tips.append(("🌙", "Sleep goals!", f"{sleep} hours is perfect. Your brain and body are fully recharged."))
    elif sleep >= 5:
        score += int((sleep / 7) * 25)
        tips.append(("🌙", "Almost there!", f"You got {sleep} hrs. Try to hit 7-8 hours for peak energy and focus."))
    else:
        score += int((sleep / 7) * 25)
        tips.append(("🌙", "Rest up, girlie!", f"Only {sleep} hrs of sleep? Prioritise rest tonight — you deserve it."))

    # Steps
    if steps >= 8000:
        score += 25
        tips.append(("🚶", "Active queen!", f"{steps:,} steps! You are moving and grooving today."))
    elif steps >= 5000:
        score += int((steps / 8000) * 25)
        tips.append(("🚶", "Good movement!", f"{steps:,} steps is solid. Try to reach 8,000 for full points!"))
    else:
        score += int((steps / 8000) * 25)
        tips.append(("🚶", "Time to move!", f"Only {steps:,} steps. Even a 10-min walk adds up — let's go!"))

    # Mood
    if mood >= 8:
        score += 25
        tips.append(("😊", "Radiating joy!", f"Mood {mood}/10 — you are absolutely glowing today!"))
    elif mood >= 5:
        score += int((mood / 10) * 25)
        tips.append(("😊", "Decent vibes!", f"Mood {mood}/10. Try journaling or a short walk to lift it higher."))
    else:
        score += int((mood / 10) * 25)
        tips.append(("😊", "Sending love!", f"Mood {mood}/10. Low days happen. Be gentle with yourself today 💕"))

    return score, tips


def get_score_message(score):
    if score >= 95:  return "Perfect wellness day! You are an absolute icon! 👑"
    elif score >= 80: return "Thriving! You are glowing from the inside out! ✨"
    elif score >= 60: return "Looking good! Keep nurturing yourself! 🌱"
    elif score >= 40: return "A decent start — small wins lead to big changes! 💪"
    else:             return "Your body needs some love today — you got this! 💕"


def get_score_color(score):
    if score >= 80:   return "#2D9B6F"
    elif score >= 60: return "#5EC99A"
    elif score >= 40: return "#EF9F27"
    else:             return "#D4537E"


# ── UI ───────────────────────────────────────────────────────

# Header
st.markdown("""
<div class="header-box">
    <h1>🌿 Daily Wellness Check-in</h1>
    <p>Enter your numbers and get your glow-up tips ✨</p>
</div>
""", unsafe_allow_html=True)

st.markdown("**By Rachel Ingabire** · INGRA DIGITAL HUB · CS Girlies Workshop 🌸")
st.markdown("---")

# Input fields
st.markdown("### 📋 How did you do today?")

col1, col2 = st.columns(2)

with col1:
    water = st.number_input("💧 Water intake (glasses)", min_value=0.0, max_value=20.0, value=0.0, step=0.5)
    steps = st.number_input("🚶 Steps walked", min_value=0, max_value=50000, value=0, step=100)

with col2:
    sleep = st.number_input("🌙 Sleep hours", min_value=0.0, max_value=12.0, value=0.0, step=0.5)
    mood  = st.number_input("😊 Mood score (1–10)", min_value=1, max_value=10, value=5, step=1)

st.markdown("")

# Submit button
if st.button("✨ Check My Wellness"):

    score, tips = analyse(water, sleep, steps, mood)
    color = get_score_color(score)

    st.markdown("---")

    # Score card
    st.markdown(f"""
    <div class="score-card">
        <div class="score-label">Your wellness score today</div>
        <div class="score-number" style="color:{color}">{score}%</div>
        <div class="score-msg">{get_score_message(score)}</div>
    </div>
    """, unsafe_allow_html=True)

    # Metrics
    st.markdown('<div class="section-title">📊 How you did today</div>', unsafe_allow_html=True)

    m1, m2, m3 = st.columns(3)
    with m1:
        st.markdown(f'<div class="metric-card"><div class="metric-label">💧 Water</div><div class="metric-val">{water:.0f} / 8 glasses</div></div>', unsafe_allow_html=True)
        st.progress(min(water / 8, 1.0))
    with m2:
        st.markdown(f'<div class="metric-card"><div class="metric-label">🌙 Sleep</div><div class="metric-val">{sleep} / 8 hrs</div></div>', unsafe_allow_html=True)
        st.progress(min(sleep / 8, 1.0))
    with m3:
        st.markdown(f'<div class="metric-card"><div class="metric-label">🚶 Steps</div><div class="metric-val">{steps:,}</div></div>', unsafe_allow_html=True)
        st.progress(min(steps / 8000, 1.0))

    # Tips
    st.markdown('<div class="section-title">💕 Your personal wellness tips</div>', unsafe_allow_html=True)

    for emoji, title, body in tips:
        st.markdown(f"""
        <div class="tip-card">
            <div class="tip-title">{emoji} {title}</div>
            <div class="tip-body">{body}</div>
        </div>
        """, unsafe_allow_html=True)

    st.markdown("---")
    st.markdown("🌿 *Built with Python & Streamlit · By Rachel Ingabire · racheltechguide.blogspot.com*")

